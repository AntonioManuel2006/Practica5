package vista;

import javax.swing.*;
import java.awt.*;

public class PanelAcercaDe extends JPanel {

    public PanelAcercaDe(Principal principal) {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.gridx = 0;

        JLabel lblTitulo = new JLabel("Gestion de Peliculas");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
        gbc.gridy = 0; add(lblTitulo, gbc);

        gbc.gridy = 1; add(new JLabel("Version: 1.0"), gbc);
        gbc.gridy = 2; add(new JLabel("Autor: [Tu nombre aqui]"), gbc);
        gbc.gridy = 3; add(new JLabel("Asignatura: Acceso a Datos"), gbc);
        gbc.gridy = 4; add(new JLabel("Curso: 2024/2025"), gbc);
        gbc.gridy = 5;
        JLabel lblInfo = new JLabel("Inicia sesion para acceder a la aplicacion.");
        lblInfo.setForeground(Color.GRAY);
        add(lblInfo, gbc);
    }
}
