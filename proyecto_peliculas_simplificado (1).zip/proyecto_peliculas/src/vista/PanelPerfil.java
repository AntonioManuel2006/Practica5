package vista;

import modelo.*;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 * Panel que muestra el perfil del director logueado.
 * Permite cambiar la foto y modificar la fecha de nacimiento.
 */
public class PanelPerfil extends JPanel {

    private static final String CARPETA_FOTOS = "fotos";
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final Principal principal;
    private final JLabel lblFoto;
    private final JTextField txtFecha;
    private String fotoActual;

    public PanelPerfil(Principal principal) {
        this.principal = principal;
        Director d = principal.getDirector();
        fotoActual = d.getFoto();

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));

        // ---- Panel izquierdo: foto del director ----
        lblFoto = crearLabelFoto();
        cargarFoto(fotoActual);

        JButton btnCambiarFoto = new JButton("Cambiar foto...");
        btnCambiarFoto.addActionListener(e -> seleccionarFoto());

        JPanel panelFoto = new JPanel(new BorderLayout(4, 4));
        panelFoto.add(lblFoto, BorderLayout.CENTER);
        panelFoto.add(btnCambiarFoto, BorderLayout.SOUTH);

        // ---- Panel central: datos del director ----
        JPanel panelDatos = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 6, 5, 6);

        // Añadimos cada campo con un helper para no repetir código
        int fila = 0;
        fila = addFila(panelDatos, gbc, fila, "ID:",               String.valueOf(d.getId()), false);
        fila = addFila(panelDatos, gbc, fila, "Nombre:",           d.getNombre(), false);
        fila = addFila(panelDatos, gbc, fila, "Usuario:",          d.getUsuario(), false);
        fila = addFila(panelDatos, gbc, fila, "Nacionalidad:",     d.getNacionalidad() != null ? d.getNacionalidad() : "", false);
        String tutor = d.getDirTutor() != null ? "ID " + d.getDirTutor() : "Ninguno";
        fila = addFila(panelDatos, gbc, fila, "Director mentor:",  tutor, false);

        // El campo de fecha SÍ es editable
        txtFecha = new JTextField(12);
        if (d.getFechaNac() != null) txtFecha.setText(d.getFechaNac().format(FMT));
        addFilaEditable(panelDatos, gbc, fila, "Fecha nac. (dd/MM/yyyy):", txtFecha);

        // ---- Botón guardar ----
        JButton btnGuardar = new JButton("Guardar cambios");
        btnGuardar.addActionListener(e -> guardar());

        add(panelFoto,  BorderLayout.WEST);
        add(panelDatos, BorderLayout.CENTER);
        add(btnGuardar, BorderLayout.SOUTH);
    }

    // ----------------------------------------------------------------
    // Helpers para construir filas del formulario
    // ----------------------------------------------------------------

    /** Añade una fila con etiqueta y valor de solo lectura. Devuelve la siguiente fila disponible. */
    private int addFila(JPanel panel, GridBagConstraints gbc, int fila, String etiqueta, String valor, boolean editable) {
        gbc.gridx = 0; gbc.gridy = fila; gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel(etiqueta), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        panel.add(new JLabel(valor), gbc);
        return fila + 1;
    }

    /** Añade una fila con etiqueta y un campo de texto editable. */
    private void addFilaEditable(JPanel panel, GridBagConstraints gbc, int fila, String etiqueta, JTextField campo) {
        gbc.gridx = 0; gbc.gridy = fila; gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel(etiqueta), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        panel.add(campo, gbc);
    }

    /** Crea el JLabel cuadrado donde se muestra la foto. */
    private JLabel crearLabelFoto() {
        JLabel lbl = new JLabel("Sin foto");
        lbl.setPreferredSize(new Dimension(140, 160));
        lbl.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        lbl.setHorizontalAlignment(SwingConstants.CENTER);
        return lbl;
    }

    // ----------------------------------------------------------------
    // Gestión de la foto
    // ----------------------------------------------------------------

    /** Abre un selector de fichero y copia la imagen elegida a la carpeta fotos/. */
    private void seleccionarFoto() {
        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new FileNameExtensionFilter("Imagenes (jpg, png, gif)", "jpg", "jpeg", "png", "gif"));
        if (fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;

        File origen = fc.getSelectedFile();
        try {
            // Crear la carpeta fotos/ si no existe y copiar la imagen
            File dir = new File(CARPETA_FOTOS);
            if (!dir.exists()) dir.mkdir();
            Files.copy(origen.toPath(), new File(dir, origen.getName()).toPath(), StandardCopyOption.REPLACE_EXISTING);
            fotoActual = origen.getName();
            cargarFoto(fotoActual);
        } catch (IOException ex) {
            GestionLog.registrar(ex);
            mostrarError(110);
        }
    }

    /** Carga y escala la imagen del director en el JLabel. */
    private void cargarFoto(String nombreFichero) {
        File f = (nombreFichero != null && !nombreFichero.isBlank())
                 ? new File(CARPETA_FOTOS + File.separator + nombreFichero)
                 : null;

        if (f == null || !f.exists()) {
            lblFoto.setIcon(null);
            lblFoto.setText("Sin foto");
            return;
        }

        // Escalar la imagen al tamaño del JLabel
        Image img = new ImageIcon(f.getAbsolutePath()).getImage()
                        .getScaledInstance(140, 160, Image.SCALE_SMOOTH);
        lblFoto.setIcon(new ImageIcon(img));
        lblFoto.setText("");
    }

    // ----------------------------------------------------------------
    // Guardar cambios en la BD
    // ----------------------------------------------------------------

    private void guardar() {
        LocalDate fecha = parsearFecha(txtFecha.getText().trim());
        // parsearFecha muestra el error si el formato es incorrecto y devuelve null con el flag de error
        if (errorEnFecha) return;

        try {
            Director d = principal.getDirector();
            int filas = GestionDirector.actualizarFotoYFecha(d.getId(), fotoActual, fecha);
            if (filas > 0) {
                // Actualizar el objeto director en memoria para reflejar los cambios
                d.setFoto(fotoActual);
                d.setFechaNac(fecha);
                JOptionPane.showMessageDialog(this, "Datos guardados correctamente.", "OK", JOptionPane.INFORMATION_MESSAGE);
            } else {
                mostrarError(109);
            }
        } catch (MiExcepcion ex) {
            mostrarError(ex.getCodigo());
        }
    }

    // Flag auxiliar para saber si parsearFecha encontró un error
    private boolean errorEnFecha = false;

    /**
     * Convierte el texto de fecha al formato dd/MM/yyyy en un LocalDate.
     * Si el texto está vacío devuelve null (la fecha es opcional).
     * Si el formato es incorrecto o la fecha es futura, muestra el error y pone errorEnFecha=true.
     */
    private LocalDate parsearFecha(String texto) {
        errorEnFecha = false;
        if (texto.isEmpty()) return null;
        try {
            LocalDate fecha = LocalDate.parse(texto, FMT);
            if (fecha.isAfter(LocalDate.now())) {
                mostrarError(112);
                errorEnFecha = true;
                return null;
            }
            return fecha;
        } catch (DateTimeParseException ex) {
            GestionLog.registrar(ex);
            mostrarError(111);
            errorEnFecha = true;
            return null;
        }
    }

    // ----------------------------------------------------------------
    // Helpers
    // ----------------------------------------------------------------

    private void mostrarError(int codigo) {
        JOptionPane.showMessageDialog(this, CodigosError.getMensaje(codigo), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
