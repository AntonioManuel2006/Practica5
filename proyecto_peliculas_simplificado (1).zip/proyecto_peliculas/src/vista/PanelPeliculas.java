package vista;

import modelo.*;
import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * Panel principal: navega las películas del director (una a una),
 * muestra la lista de guiones y permite dar de alta/baja guiones.
 */
public class PanelPeliculas extends JPanel {

    private final Principal principal;
    private final CursorPeliculas cursor = new CursorPeliculas();

    // ---- Campos de solo lectura para mostrar los datos de la película ----
    private final JTextField fTitulo      = campoSoloLectura();
    private final JTextField fGenero      = campoSoloLectura();
    private final JTextField fAnio        = campoSoloLectura();
    private final JTextField fPresupuesto = campoSoloLectura();
    private final JTextField fDurTotal    = campoSoloLectura();
    private final JTextField fDurMax      = campoSoloLectura();

    // ---- Botones de navegación ----
    private final JButton btnPrimero   = new JButton("|<");
    private final JButton btnAnterior  = new JButton("<");
    private final JButton btnSiguiente = new JButton(">");
    private final JButton btnUltimo    = new JButton(">|");
    private final JLabel  lblPos       = new JLabel("0/0");  // posición actual / total

    // ---- Lista de guiones ----
    private final DefaultListModel<String> modeloLista = new DefaultListModel<>();
    private final JList<String>            listaGuiones = new JList<>(modeloLista);

    public PanelPeliculas(Principal principal) {
        this.principal = principal;
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));

        add(crearPanelIzquierdo(), BorderLayout.CENTER);
        add(crearPanelGuiones(),   BorderLayout.EAST);

        // Conectar botones de navegación a los métodos del cursor
        btnPrimero.addActionListener(e   -> { cursor.irPrimero();   refrescar(); });
        btnAnterior.addActionListener(e  -> { cursor.retroceder();  refrescar(); });
        btnSiguiente.addActionListener(e -> { cursor.avanzar();     refrescar(); });
        btnUltimo.addActionListener(e    -> { cursor.irUltimo();    refrescar(); });

        cargarPeliculas();
    }

    // ----------------------------------------------------------------
    // Construcción de paneles
    // ----------------------------------------------------------------

    /** Panel izquierdo: campos de la película + botones de navegación. */
    private JPanel crearPanelIzquierdo() {
        // Etiquetas y campos en el mismo orden
        String[]      etiquetas = {"Titulo:", "Genero:", "Año:", "Presupuesto €:", "Duracion actual:", "Duracion maxima:"};
        JTextField[]  campos    = {fTitulo, fGenero, fAnio, fPresupuesto, fDurTotal, fDurMax};

        JPanel datos = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(4, 6, 4, 6);

        for (int i = 0; i < etiquetas.length; i++) {
            g.gridx = 0; g.gridy = i; g.anchor = GridBagConstraints.EAST;
            datos.add(new JLabel(etiquetas[i]), g);
            g.gridx = 1; g.anchor = GridBagConstraints.WEST; g.fill = GridBagConstraints.HORIZONTAL;
            datos.add(campos[i], g);
        }

        JPanel navegacion = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 4));
        navegacion.add(btnPrimero);
        navegacion.add(btnAnterior);
        navegacion.add(lblPos);
        navegacion.add(btnSiguiente);
        navegacion.add(btnUltimo);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(datos,     BorderLayout.CENTER);
        panel.add(navegacion, BorderLayout.SOUTH);
        return panel;
    }

    /** Panel derecho: JList de guiones + botones alta/baja. */
    private JPanel crearPanelGuiones() {
        listaGuiones.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scroll = new JScrollPane(listaGuiones);
        scroll.setPreferredSize(new Dimension(220, 180));
        scroll.setBorder(BorderFactory.createTitledBorder("Guiones"));

        JButton btnAlta = new JButton("+ Alta guion");
        JButton btnBaja = new JButton("- Baja guion");
        btnAlta.addActionListener(e -> principal.mostrarPanel(new PanelAltaGuion(principal, this)));
        btnBaja.addActionListener(e -> bajaGuion());

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 4));
        botones.add(btnAlta);
        botones.add(btnBaja);

        JPanel panel = new JPanel(new BorderLayout(4, 4));
        panel.add(scroll,   BorderLayout.CENTER);
        panel.add(botones,  BorderLayout.SOUTH);
        return panel;
    }

    // ----------------------------------------------------------------
    // Carga y refresco de datos
    // ----------------------------------------------------------------

    /** Carga las películas del director logueado en el cursor. */
    private void cargarPeliculas() {
        int dirId = principal.getDirector().getId();
        try {
            cursor.iniciar(
                "SELECT id,titulo,genero,anio,presupuesto,duracionTotal,duracionMaxima,dirId " +
                "FROM pelicula WHERE dirId=" + dirId + " ORDER BY titulo");
            refrescar();
        } catch (MiExcepcion ex) {
            mostrarError(ex.getCodigo());
        }
    }

    /** Actualiza todos los campos con la película que apunta el cursor en este momento. */
    public void refrescar() {
        Pelicula p = cursor.leer();

        // Actualizar indicador de posición
        int posicion = cursor.hayRegistros() ? cursor.getPosicion() + 1 : 0;
        lblPos.setText(posicion + "/" + cursor.getTotal());

        if (p == null) {
            limpiarCampos();
            return;
        }

        // Rellenar campos con los datos de la película actual
        fTitulo.setText(p.getTitulo());
        fGenero.setText(p.getGenero() != null ? p.getGenero() : "");
        fAnio.setText(String.valueOf(p.getAnio()));
        fPresupuesto.setText(String.format("%.2f", p.getPresupuesto()));
        fDurTotal.setText(String.format("%.1f min", p.getDuracionTotal()));
        fDurMax.setText(String.format("%.1f min",  p.getDuracionMaxima()));

        // Colorear la duración total según lo cerca que esté del tope
        colorearDuracion(p);

        cargarGuiones(p.getId());
    }

    /**
     * Colorea fDurTotal según si supera o se acerca al límite:
     *   - rojo  si ya superó o igualó la duración máxima
     *   - naranja si está por encima del 90% del tope
     *   - negro en cualquier otro caso
     */
    private void colorearDuracion(Pelicula p) {
        double total  = p.getDuracionTotal();
        double maxima = p.getDuracionMaxima();

        if (total >= maxima) {
            fDurTotal.setForeground(Color.RED);
        } else if (total >= maxima * 0.9) {
            fDurTotal.setForeground(new Color(200, 100, 0)); // naranja
        } else {
            fDurTotal.setForeground(Color.BLACK);
        }
    }

    /** Vacía todos los campos de texto y la lista de guiones. */
    private void limpiarCampos() {
        fTitulo.setText(""); fGenero.setText(""); fAnio.setText("");
        fPresupuesto.setText(""); fDurTotal.setText(""); fDurMax.setText("");
        modeloLista.clear();
    }

    // ----------------------------------------------------------------
    // Gestión de guiones
    // ----------------------------------------------------------------

    /** Carga en el JList los guiones de la película indicada. */
    private void cargarGuiones(int pelId) {
        modeloLista.clear();
        try {
            List<Guion> guiones = GestionGuion.obtenerPorPelicula(pelId);
            for (Guion g : guiones) {
                // Formato del elemento: "id | titulo  (duración min)"
                modeloLista.addElement(g.getId() + " | " + g.getTitulo() + "  (" + g.getDuracion() + " min)");
            }
        } catch (MiExcepcion ex) {
            mostrarError(ex.getCodigo());
        }
    }

    /** Elimina el guion seleccionado en la lista, previa confirmación. */
    private void bajaGuion() {
        int idx = listaGuiones.getSelectedIndex();
        if (idx < 0) {
            JOptionPane.showMessageDialog(this, "Selecciona un guion de la lista.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // El id del guion está al principio del texto: "123 | titulo..."
        int idGuion = Integer.parseInt(modeloLista.getElementAt(idx).split("\\|")[0].trim());

        int conf = JOptionPane.showConfirmDialog(this, "¿Eliminar el guion seleccionado?", "Confirmar baja", JOptionPane.YES_NO_OPTION);
        if (conf != JOptionPane.YES_OPTION) return;

        try {
            GestionGuion.eliminarGuion(idGuion);
            // Recalcular la duración total de la película y refrescar la vista
            GestionPelicula.recalcularDuracion(cursor.leer().getId());
            cursor.recargarActual();
            refrescar();
            JOptionPane.showMessageDialog(this, "Guion eliminado.", "OK", JOptionPane.INFORMATION_MESSAGE);
        } catch (MiExcepcion ex) {
            mostrarError(ex.getCodigo());
        }
    }

    // ----------------------------------------------------------------
    // Acceso externo y helpers
    // ----------------------------------------------------------------

    /** El PanelAltaGuion necesita acceder al cursor para saber la película actual. */
    public CursorPeliculas getCursorPeliculas() { return cursor; }

    private void mostrarError(int codigo) {
        JOptionPane.showMessageDialog(this, CodigosError.getMensaje(codigo), "Error", JOptionPane.ERROR_MESSAGE);
    }

    /** Crea un JTextField de solo lectura con ancho estándar. */
    private static JTextField campoSoloLectura() {
        JTextField f = new JTextField(18);
        f.setEditable(false);
        return f;
    }
}
