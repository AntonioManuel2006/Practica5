package vista;

import modelo.*;
import javax.swing.*;

/**
 * Ventana principal de la aplicacion.
 * El menu estara deshabilitado hasta que el director inicie sesion.
 */
public class Principal extends JFrame {

    private Director directorActual = null;

    // Items del menu que se habilitan tras login
    private final JMenuItem miPeliculas;
    private final JMenuItem miPerfil;
    private final JMenuItem miCerrarSesion;

    public Principal() {
        super("Gestion de Peliculas");
        setSize(720, 460);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // ---- MENU ----
        JMenuBar bar = new JMenuBar();

        // Menu Sesion
        JMenu mSesion = new JMenu("Sesion");
        JMenuItem miLogin = new JMenuItem("Iniciar sesion");
        miCerrarSesion    = new JMenuItem("Cerrar sesion");
        JMenuItem miSalir = new JMenuItem("Salir");

        miLogin.addActionListener(e -> mostrarPanel(new PanelLogin(this)));
        miCerrarSesion.addActionListener(e -> cerrarSesion());
        miSalir.addActionListener(e -> salir());

        mSesion.add(miLogin);
        mSesion.add(miCerrarSesion);
        mSesion.addSeparator();
        mSesion.add(miSalir);

        // Menu Peliculas
        JMenu mPeliculas = new JMenu("Peliculas");
        miPeliculas = new JMenuItem("Ver mis peliculas");
        miPeliculas.addActionListener(e -> mostrarPanel(new PanelPeliculas(this)));
        mPeliculas.add(miPeliculas);

        // Menu Director
        JMenu mDirector = new JMenu("Mi perfil");
        miPerfil = new JMenuItem("Ver / editar perfil");
        miPerfil.addActionListener(e -> mostrarPanel(new PanelPerfil(this)));
        mDirector.add(miPerfil);

        // Menu Acerca de
        JMenu mInfo = new JMenu("Ayuda");
        JMenuItem miAcerca = new JMenuItem("Acerca de...");
        miAcerca.addActionListener(e -> mostrarPanel(new PanelAcercaDe(this)));
        mInfo.add(miAcerca);

        bar.add(mSesion);
        bar.add(mPeliculas);
        bar.add(mDirector);
        bar.add(mInfo);
        setJMenuBar(bar);

        // ---- Estado inicial: menu deshabilitado ----
        setMenuHabilitado(false);

        // ---- Panel de bienvenida ----
        mostrarPanel(new PanelAcercaDe(this));

        // ---- Cerrar conexion al salir ----
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                GestionConexion.cerrarConexion();
            }
        });

        setVisible(true);

        // ---- Conexion a la BD al arrancar ----
        try {
            GestionConexion.crearConexion();
        } catch (MiExcepcion ex) {
            JOptionPane.showMessageDialog(this,
                CodigosError.getMensaje(ex.getCodigo()),
                "Error de conexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ----------------------------------------------------------------
    // Gestion de paneles
    // ----------------------------------------------------------------

    public void mostrarPanel(JPanel panel) {
        setContentPane(panel);
        revalidate();
        repaint();
    }

    // ----------------------------------------------------------------
    // Sesion
    // ----------------------------------------------------------------

    private void cerrarSesion() {
        directorActual = null;
        setMenuHabilitado(false);
        mostrarPanel(new PanelAcercaDe(this));
        JOptionPane.showMessageDialog(this, "Sesion cerrada.",
            "Sesion", JOptionPane.INFORMATION_MESSAGE);
    }

    private void salir() {
        GestionConexion.cerrarConexion();
        System.exit(0);
    }

    public void setMenuHabilitado(boolean habilitado) {
        miPeliculas.setEnabled(habilitado);
        miPerfil.setEnabled(habilitado);
        miCerrarSesion.setEnabled(habilitado);
    }

    // ----------------------------------------------------------------
    // Getters / Setters
    // ----------------------------------------------------------------

    public Director getDirector() { return directorActual; }
    public void setDirector(Director d) { this.directorActual = d; }
}
