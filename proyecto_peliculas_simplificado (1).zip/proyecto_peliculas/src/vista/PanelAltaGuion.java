package vista;

import modelo.*;
import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 * Panel para dar de alta un nuevo guion en la película actual.
 * Al aceptar, comprueba que no se supera la duración máxima y
 * recalcula el campo duracionTotal de la película.
 */
public class PanelAltaGuion extends JPanel {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final Principal      principal;
    private final PanelPeliculas panelPeliculas;

    // ---- Campos del formulario ----
    private final JTextField txtTitulo      = new JTextField(18);
    private final JTextField txtDuracion    = new JTextField(8);
    private final JTextField txtPaginas     = new JTextField(6);
    private final JTextField txtFecha       = new JTextField(10);
    private final JTextField txtDescripcion = new JTextField(20);

    public PanelAltaGuion(Principal principal, PanelPeliculas panelPeliculas) {
        this.principal      = principal;
        this.panelPeliculas = panelPeliculas;

        setLayout(new GridBagLayout());
        setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 6, 5, 6);

        // Título del panel
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        JLabel titulo = new JLabel("Nuevo Guion");
        titulo.setFont(new Font("Arial", Font.BOLD, 14));
        add(titulo, gbc);
        gbc.gridwidth = 1;

        // Filas del formulario (etiqueta + campo)
        addCampo(gbc, 1, "Titulo:",                    txtTitulo);
        addCampo(gbc, 2, "Duracion (min):",            txtDuracion);
        addCampo(gbc, 3, "Paginas:",                   txtPaginas);
        addCampo(gbc, 4, "Fecha entrega (dd/MM/yyyy):", txtFecha);
        addCampo(gbc, 5, "Descripcion:",               txtDescripcion);

        // Botones Aceptar / Volver
        gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        JButton btnAceptar = new JButton("Aceptar");
        JButton btnVolver  = new JButton("Volver");
        btnAceptar.addActionListener(e -> insertar());
        btnVolver.addActionListener(e  -> principal.mostrarPanel(panelPeliculas));
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        botones.add(btnAceptar);
        botones.add(btnVolver);
        add(botones, gbc);
    }

    // ----------------------------------------------------------------
    // Construcción del formulario
    // ----------------------------------------------------------------

    /** Añade una fila con etiqueta a la izquierda y campo a la derecha. */
    private void addCampo(GridBagConstraints gbc, int fila, String etiqueta, JTextField campo) {
        gbc.gridx = 0; gbc.gridy = fila; gbc.anchor = GridBagConstraints.EAST;
        add(new JLabel(etiqueta), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        add(campo, gbc);
    }

    // ----------------------------------------------------------------
    // Inserción del guion
    // ----------------------------------------------------------------

    /** Valida los campos, comprueba el tope de duración e inserta el guion en la BD. */
    private void insertar() {
        // 1. Validar campos obligatorios
        String titulo = txtTitulo.getText().trim();
        String durStr = txtDuracion.getText().trim();
        if (titulo.isEmpty() || durStr.isEmpty()) {
            mostrarError(111);
            return;
        }

        // 2. Parsear duración y páginas
        double duracion;
        int    paginas = 0;
        try {
            duracion = Double.parseDouble(durStr);
            if (!txtPaginas.getText().trim().isEmpty())
                paginas = Integer.parseInt(txtPaginas.getText().trim());
        } catch (NumberFormatException ex) {
            GestionLog.registrar(ex);
            mostrarError(111);
            return;
        }

        // 3. Parsear fecha (campo opcional)
        LocalDate fecha = parsearFecha(txtFecha.getText().trim());
        if (errorFecha) return; // parsearFecha ya mostró el mensaje de error

        // 4. Comprobar que no se supera la duración máxima de la película
        Pelicula pel = panelPeliculas.getCursorPeliculas().leer();
        if (pel != null && (pel.getDuracionTotal() + duracion) > pel.getDuracionMaxima()) {
            JOptionPane.showMessageDialog(this,
                CodigosError.getMensaje(108) +
                "\nMaxima: "         + pel.getDuracionMaxima() + " min" +
                "\nTotal tras alta: " + (pel.getDuracionTotal() + duracion) + " min",
                "Tope superado", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 5. Insertar en la BD
        try {
            Guion g = new Guion(0, titulo, duracion, paginas, fecha,
                                txtDescripcion.getText().trim(), pel.getId());
            GestionGuion.insertarGuion(g);

            // Recalcular campo calculado y refrescar la vista anterior
            GestionPelicula.recalcularDuracion(g.getPelId());
            panelPeliculas.getCursorPeliculas().recargarActual();
            panelPeliculas.refrescar();

            JOptionPane.showMessageDialog(this, "Guion insertado correctamente.", "OK", JOptionPane.INFORMATION_MESSAGE);
            principal.mostrarPanel(panelPeliculas);
        } catch (MiExcepcion ex) {
            mostrarError(ex.getCodigo());
        }
    }

    // ----------------------------------------------------------------
    // Helpers
    // ----------------------------------------------------------------

    /** Flag que indica si parsearFecha encontró un error. */
    private boolean errorFecha = false;

    /**
     * Convierte el texto en LocalDate (formato dd/MM/yyyy).
     * Si está vacío devuelve null (la fecha es opcional).
     * Si hay error muestra el mensaje y activa errorFecha.
     */
    private LocalDate parsearFecha(String texto) {
        errorFecha = false;
        if (texto.isEmpty()) return null;
        try {
            LocalDate fecha = LocalDate.parse(texto, FMT);
            if (fecha.isAfter(LocalDate.now())) {
                mostrarError(112);
                errorFecha = true;
                return null;
            }
            return fecha;
        } catch (DateTimeParseException ex) {
            GestionLog.registrar(ex);
            mostrarError(111);
            errorFecha = true;
            return null;
        }
    }

    private void mostrarError(int codigo) {
        JOptionPane.showMessageDialog(this, CodigosError.getMensaje(codigo), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
