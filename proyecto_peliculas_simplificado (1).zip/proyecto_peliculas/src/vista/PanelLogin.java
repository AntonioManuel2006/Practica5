package vista;

import modelo.*;
import javax.swing.*;
import java.awt.*;

public class PanelLogin extends JPanel {

    private final Principal principal;
    private final JTextField txtUsuario;
    private final JPasswordField txtContrasena;

    public PanelLogin(Principal principal) {
        this.principal = principal;
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 8, 6, 8);

        // Titulo
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        JLabel lblTitulo = new JLabel("Inicio de sesion");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 14));
        add(lblTitulo, gbc);
        gbc.gridwidth = 1;

        // Usuario
        gbc.gridx = 0; gbc.gridy = 1; gbc.anchor = GridBagConstraints.EAST;
        add(new JLabel("Usuario:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        txtUsuario = new JTextField(16);
        add(txtUsuario, gbc);

        // Contrasena
        gbc.gridx = 0; gbc.gridy = 2; gbc.anchor = GridBagConstraints.EAST;
        add(new JLabel("Contrasena:"), gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.WEST;
        txtContrasena = new JPasswordField(16);
        add(txtContrasena, gbc);

        // Boton
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        JButton btnEntrar = new JButton("Entrar");
        btnEntrar.addActionListener(e -> iniciarSesion());
        // Permite pulsar Enter en el campo contrasena
        txtContrasena.addActionListener(e -> iniciarSesion());
        add(btnEntrar, gbc);
    }

    private void iniciarSesion() {
        String usuario   = txtUsuario.getText().trim();
        String contrasena = new String(txtContrasena.getPassword());

        if (usuario.isEmpty() || contrasena.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                CodigosError.getMensaje(111), "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            Director d = GestionConexion.validarDirector(usuario, contrasena);
            if (d != null) {
                principal.setDirector(d);
                principal.setMenuHabilitado(true);
                JOptionPane.showMessageDialog(this,
                    "Bienvenido, " + d.getNombre() + "!", "Sesion iniciada",
                    JOptionPane.INFORMATION_MESSAGE);
                // Preparar PreparedStatement de guiones
                GestionGuion.prepararConsultas();
                principal.mostrarPanel(new PanelAcercaDe(principal));
            } else {
                JOptionPane.showMessageDialog(this,
                    CodigosError.getMensaje(104), "Acceso denegado", JOptionPane.ERROR_MESSAGE);
                txtContrasena.setText("");
            }
        } catch (MiExcepcion ex) {
            JOptionPane.showMessageDialog(this,
                CodigosError.getMensaje(ex.getCodigo()), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
