package app;

import vista.Principal;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        // Lanzar la interfaz grafica en el hilo de eventos de Swing
        SwingUtilities.invokeLater(Principal::new);
    }
}
