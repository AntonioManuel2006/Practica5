package modelo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Cursor para navegar las películas una a una, igual que un ResultSet
 * pero guardado en memoria como una List<Pelicula>.
 *
 * Ciclo de uso típico:
 *   1. cursor.iniciar(sql)    → carga las películas y va a la primera
 *   2. cursor.leer()          → obtiene la película actual
 *   3. cursor.avanzar() / retroceder() / irPrimero() / irUltimo()
 *   4. cursor.finalizar()     → libera la lista
 *
 * Después de insertar o borrar guiones, llama a recargarActual()
 * para que la película actual refleje la nueva duracionTotal.
 */
public class CursorPeliculas {

    private List<Pelicula> lista = new ArrayList<>();
    private int pos = -1; // posición actual en la lista (-1 = vacío)

    // ----------------------------------------------------------------
    // Carga y limpieza
    // ----------------------------------------------------------------

    /**
     * Ejecuta la SQL y carga las películas resultantes en la lista.
     * Posiciona el cursor en la primera película si hay resultados.
     */
    public void iniciar(String sql) throws MiExcepcion {
        Connection con = GestionConexion.getConexion();
        if (con == null) throw new MiExcepcion(102);

        lista.clear();
        pos = -1;

        try {
            ResultSet rs = con.createStatement().executeQuery(sql);
            while (rs.next()) {
                lista.add(new Pelicula(
                    rs.getInt("id"),
                    rs.getString("titulo"),
                    rs.getString("genero"),
                    rs.getInt("anio"),
                    rs.getDouble("presupuesto"),
                    rs.getDouble("duracionTotal"),
                    rs.getDouble("duracionMaxima"),
                    rs.getInt("dirId")
                ));
            }
            if (!lista.isEmpty()) pos = 0; // ir a la primera
        } catch (SQLException e) {
            GestionLog.registrar(e);
            throw new MiExcepcion(103, e.getMessage());
        }
    }

    /** Vacía la lista y resetea la posición. */
    public void finalizar() {
        lista.clear();
        pos = -1;
    }

    // ----------------------------------------------------------------
    // Lectura
    // ----------------------------------------------------------------

    /** Devuelve la película que apunta el cursor, o null si la lista está vacía. */
    public Pelicula leer() {
        if (pos < 0 || pos >= lista.size()) return null;
        return lista.get(pos);
    }

    // ----------------------------------------------------------------
    // Navegación
    // ----------------------------------------------------------------

    /** Avanza al siguiente. Devuelve true si el movimiento fue posible. */
    public boolean avanzar() {
        if (pos < lista.size() - 1) { pos++; return true; }
        return false;
    }

    /** Retrocede al anterior. Devuelve true si el movimiento fue posible. */
    public boolean retroceder() {
        if (pos > 0) { pos--; return true; }
        return false;
    }

    /** Va directamente a la primera película. */
    public void irPrimero() { if (!lista.isEmpty()) pos = 0; }

    /** Va directamente a la última película. */
    public void irUltimo()  { if (!lista.isEmpty()) pos = lista.size() - 1; }

    // ----------------------------------------------------------------
    // Información del estado
    // ----------------------------------------------------------------

    public boolean hayRegistros() { return !lista.isEmpty(); }
    public int     getPosicion()  { return pos; }
    public int     getTotal()     { return lista.size(); }

    // ----------------------------------------------------------------
    // Refresco tras cambios en guiones
    // ----------------------------------------------------------------

    /**
     * Vuelve a cargar desde la BD la película en la posición actual.
     * Necesario después de insertar o borrar guiones para que
     * duracionTotal aparezca actualizada en la vista.
     */
    public void recargarActual() throws MiExcepcion {
        if (pos < 0 || pos >= lista.size()) return;
        Pelicula actualizada = GestionPelicula.obtenerPelicula(lista.get(pos).getId());
        if (actualizada != null) lista.set(pos, actualizada);
    }
}
