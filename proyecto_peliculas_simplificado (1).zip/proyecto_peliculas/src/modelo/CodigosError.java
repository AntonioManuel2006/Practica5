package modelo;

import java.util.HashMap;
import java.util.Map;

/**
 * Diccionario central de mensajes de error para el usuario.
 *
 * Cuando se captura una MiExcepcion, se usa su código para obtener
 * aquí el texto que se muestra en el JOptionPane.
 *
 * Uso:
 *   String mensaje = CodigosError.getMensaje(ex.getCodigo());
 */
public class CodigosError {

    // Mapa código → mensaje legible por el usuario
    private static final Map<Integer, String> ERRORES = new HashMap<>();

    // Se rellena una sola vez al cargar la clase
    static {
        ERRORES.put(101, "Error 101: No se encontró el driver JDBC de MySQL.");
        ERRORES.put(102, "Error 102: No hay conexión a la base de datos.");
        ERRORES.put(103, "Error 103: Falló la consulta SQL.");
        ERRORES.put(104, "Error 104: Usuario o contraseña incorrectos.");
        ERRORES.put(105, "Error 105: No hay registros disponibles.");
        ERRORES.put(106, "Error 106: No se pudo insertar el registro.");
        ERRORES.put(107, "Error 107: No se pudo eliminar el registro.");
        ERRORES.put(108, "Error 108: Duración máxima de la película superada.");
        ERRORES.put(109, "Error 109: No se pudo actualizar el registro.");
        ERRORES.put(110, "Error 110: No se pudo copiar la imagen.");
        ERRORES.put(111, "Error 111: Datos incompletos o con formato incorrecto.");
        ERRORES.put(112, "Error 112: La fecha no puede ser futura.");
        ERRORES.put(999, "Error 999: Error desconocido del sistema.");
    }

    /** Devuelve el mensaje asociado al código, o un mensaje genérico si no existe. */
    public static String getMensaje(int codigo) {
        return ERRORES.getOrDefault(codigo, "Error " + codigo + ": error desconocido.");
    }
}
