package modelo;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Guarda en un fichero de texto los errores técnicos del sistema.
 *
 * - Los errores técnicos (SQLException, IOException…) se registran aquí.
 * - Los mensajes de error para el usuario se obtienen de CodigosError.
 *
 * El fichero se llama "peliculas_errores.log" y se crea en el directorio
 * de trabajo de la aplicación. Cada línea tiene la forma:
 *   [2025-04-08 10:30:00] java.sql.SQLException: ...
 */
public class GestionLog {

    private static final String FICHERO = "peliculas_errores.log";
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /** Registra una excepción: guarda clase y mensaje. */
    public static void registrar(Exception e) {
        escribir(e.getClass().getName() + ": " + e.getMessage());
    }

    /** Registra un mensaje de texto libre. */
    public static void registrar(String mensaje) {
        escribir(mensaje);
    }

    /** Añade una línea con timestamp al fichero de log (y también a la consola de errores). */
    private static void escribir(String texto) {
        String linea = "[" + LocalDateTime.now().format(FMT) + "] " + texto;
        System.err.println(linea); // útil durante el desarrollo en PyCharm/IntelliJ

        // Abrimos con append=true para no borrar entradas anteriores
        try (PrintWriter pw = new PrintWriter(new FileWriter(FICHERO, true))) {
            pw.println(linea);
        } catch (IOException ioEx) {
            System.err.println("No se pudo escribir en el log: " + ioEx.getMessage());
        }
    }
}
