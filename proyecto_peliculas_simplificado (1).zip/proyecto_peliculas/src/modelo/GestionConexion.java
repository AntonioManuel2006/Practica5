package modelo;

import java.sql.*;

/**
 * Gestiona la conexión única a MySQL y el inicio de sesión del director.
 *
 * Patrón Singleton: solo existe una conexión durante toda la ejecución.
 * Se abre en Main al arrancar y se cierra al cerrar la ventana.
 *
 * Credenciales por defecto (ajústalas si tu Docker usa otras):
 *   URL:      jdbc:mysql://localhost:3306/bdpeliculas
 *   Usuario:  peliuser
 *   Password: pelipass
 */
public class GestionConexion {

    private static final String URL     = "jdbc:mysql://localhost:3306/bdpeliculas?useSSL=false&serverTimezone=UTC";
    private static final String USUARIO = "peliuser";
    private static final String PASS    = "pelipass";

    // La conexión y el director logueado se guardan como variables estáticas
    private static Connection con              = null;
    private static Director   directorValidado = null;

    // ----------------------------------------------------------------
    // Abrir y cerrar conexión
    // ----------------------------------------------------------------

    /**
     * Abre la conexión con MySQL.
     * Si ya existe una conexión abierta, no hace nada.
     * Lanza MiExcepcion(101) si no encuentra el driver JDBC.
     * Lanza MiExcepcion(102) si no puede conectarse a la BD.
     */
    public static void crearConexion() throws MiExcepcion {
        if (con != null) return; // ya estaba abierta

        // Cargar el driver de MySQL
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            GestionLog.registrar(e);
            throw new MiExcepcion(101, e.getMessage());
        }

        // Establecer la conexión
        try {
            con = DriverManager.getConnection(URL, USUARIO, PASS);
        } catch (SQLException e) {
            GestionLog.registrar(e);
            throw new MiExcepcion(102, e.getMessage());
        }
    }

    /** Cierra la conexión con la BD si estaba abierta. */
    public static void cerrarConexion() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
                con = null;
            }
        } catch (Exception e) {
            GestionLog.registrar(e);
        }
    }

    /** Devuelve la conexión activa (puede ser null si no se ha abierto aún). */
    public static Connection getConexion() {
        return con;
    }

    // ----------------------------------------------------------------
    // Login del director
    // ----------------------------------------------------------------

    /**
     * Comprueba si el usuario y contraseña son correctos.
     * Usa PreparedStatement para evitar inyección SQL.
     *
     * @return el Director si las credenciales son válidas, null si son incorrectas.
     */
    public static Director validarDirector(String usuario, String contrasena) throws MiExcepcion {
        if (con == null) throw new MiExcepcion(102);
        try {
            PreparedStatement ps = con.prepareStatement(
                "SELECT id, nombre, usuario, contrasena, nacionalidad, fechaNac, foto, dirTutor " +
                "FROM director WHERE usuario = ? AND contrasena = ?");
            ps.setString(1, usuario);
            ps.setString(2, contrasena);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                // Credenciales correctas → guardar el director en memoria
                directorValidado = mapearDirector(rs);
                return directorValidado;
            }
            return null; // credenciales incorrectas
        } catch (SQLException e) {
            GestionLog.registrar(e);
            throw new MiExcepcion(103, e.getMessage());
        }
    }

    // ----------------------------------------------------------------
    // Director en sesión
    // ----------------------------------------------------------------

    public static Director getDirectorValidado()        { return directorValidado; }
    public static void     setDirectorValidado(Director d) { directorValidado = d; }

    // ----------------------------------------------------------------
    // Helper: convertir una fila del ResultSet en un objeto Director
    // ----------------------------------------------------------------

    /**
     * Crea un Director a partir de la fila actual del ResultSet.
     * Es estático y accesible desde GestionDirector para no duplicar código.
     */
    static Director mapearDirector(ResultSet rs) throws SQLException {
        Date     sqlDate = rs.getDate("fechaNac");
        Integer  tutor   = rs.getObject("dirTutor") != null ? rs.getInt("dirTutor") : null;

        return new Director(
            rs.getInt("id"),
            rs.getString("nombre"),
            rs.getString("usuario"),
            rs.getString("contrasena"),
            rs.getString("nacionalidad"),
            sqlDate != null ? sqlDate.toLocalDate() : null,
            rs.getString("foto"),
            tutor
        );
    }
}
