package modelo;

import java.sql.*;
import java.time.LocalDate;

/**
 * Operaciones de acceso a datos de la tabla director.
 *
 * Métodos disponibles:
 *   - obtenerDirector(sql)               → busca un director con la SQL indicada
 *   - actualizarFotoYFecha(id, foto, fecha) → actualiza foto y fecha de nacimiento
 */
public class GestionDirector {

    /**
     * Ejecuta la SQL recibida y devuelve el primer Director encontrado.
     * Devuelve null si no hay resultados.
     *
     * Ejemplo de uso:
     *   obtenerDirector("SELECT ... FROM director WHERE id = 3")
     */
    public static Director obtenerDirector(String sql) throws MiExcepcion {
        Connection con = GestionConexion.getConexion();
        if (con == null) throw new MiExcepcion(102);
        try {
            ResultSet rs = con.createStatement().executeQuery(sql);
            return rs.next() ? GestionConexion.mapearDirector(rs) : null;
        } catch (SQLException e) {
            GestionLog.registrar(e);
            throw new MiExcepcion(103, e.getMessage());
        }
    }

    /**
     * Actualiza la foto y la fecha de nacimiento del director.
     * La foto puede ser null (sin foto) y la fecha también (campo opcional).
     *
     * @return número de filas afectadas (1 si se actualizó correctamente, 0 si no)
     */
    public static int actualizarFotoYFecha(int id, String foto, LocalDate fecha) throws MiExcepcion {
        Connection con = GestionConexion.getConexion();
        if (con == null) throw new MiExcepcion(102);
        try {
            PreparedStatement ps = con.prepareStatement(
                "UPDATE director SET foto = ?, fechaNac = ? WHERE id = ?");
            ps.setString(1, foto);
            ps.setDate(2, fecha != null ? Date.valueOf(fecha) : null);
            ps.setInt(3, id);
            return ps.executeUpdate();
        } catch (SQLException e) {
            GestionLog.registrar(e);
            throw new MiExcepcion(109, e.getMessage());
        }
    }
}
