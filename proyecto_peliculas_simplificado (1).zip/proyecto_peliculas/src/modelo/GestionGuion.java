package modelo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Operaciones de acceso a datos de la tabla guion.
 *
 * Métodos disponibles:
 *   - prepararConsultas()        → crea el PreparedStatement reutilizable (llamar tras login)
 *   - obtenerPorPelicula(pelId)  → guiones de una película
 *   - insertarGuion(g)           → inserta un nuevo guion
 *   - eliminarGuion(id)          → elimina un guion por su id
 *
 * Nota: después de insertar o eliminar, hay que llamar a
 *       GestionPelicula.recalcularDuracion(pelId) para actualizar
 *       el campo calculado duracionTotal de la película.
 */
public class GestionGuion {

    // PreparedStatement guardado en memoria para no recrearlo en cada consulta
    private static PreparedStatement psGuionesPorPelicula = null;

    /**
     * Prepara el PreparedStatement de búsqueda de guiones.
     * Se llama una sola vez después de que el director inicia sesión.
     * Al reutilizarlo evitamos compilar la misma consulta repetidamente.
     */
    public static void prepararConsultas() throws MiExcepcion {
        Connection con = GestionConexion.getConexion();
        if (con == null) throw new MiExcepcion(102);
        try {
            psGuionesPorPelicula = con.prepareStatement(
                "SELECT id, titulo, duracion, paginas, fechaEntrega, descripcion, pelId " +
                "FROM guion WHERE pelId = ? ORDER BY id");
        } catch (SQLException e) {
            GestionLog.registrar(e);
            throw new MiExcepcion(103, e.getMessage());
        }
    }

    // ----------------------------------------------------------------
    // SELECT
    // ----------------------------------------------------------------

    /** Devuelve todos los guiones de la película indicada. */
    public static List<Guion> obtenerPorPelicula(int pelId) throws MiExcepcion {
        // Si aún no está preparado (por ejemplo, tras reconexión), lo preparamos ahora
        if (psGuionesPorPelicula == null) prepararConsultas();

        List<Guion> lista = new ArrayList<>();
        try {
            psGuionesPorPelicula.setInt(1, pelId);
            ResultSet rs = psGuionesPorPelicula.executeQuery();
            while (rs.next()) lista.add(mapear(rs));
            return lista;
        } catch (SQLException e) {
            GestionLog.registrar(e);
            throw new MiExcepcion(103, e.getMessage());
        }
    }

    // ----------------------------------------------------------------
    // INSERT
    // ----------------------------------------------------------------

    /**
     * Inserta un nuevo guion en la BD.
     * El campo id del objeto Guion se ignora (lo asigna la BD con AUTO_INCREMENT).
     *
     * @return número de filas afectadas (1 si se insertó correctamente)
     */
    public static int insertarGuion(Guion g) throws MiExcepcion {
        Connection con = GestionConexion.getConexion();
        if (con == null) throw new MiExcepcion(102);
        try {
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO guion (titulo, duracion, paginas, fechaEntrega, descripcion, pelId) " +
                "VALUES (?, ?, ?, ?, ?, ?)");
            ps.setString(1, g.getTitulo());
            ps.setDouble(2, g.getDuracion());
            ps.setInt(3,    g.getPaginas());
            ps.setDate(4,   g.getFechaEntrega() != null ? Date.valueOf(g.getFechaEntrega()) : null);
            ps.setString(5, g.getDescripcion());
            ps.setInt(6,    g.getPelId());
            return ps.executeUpdate();
        } catch (SQLException e) {
            GestionLog.registrar(e);
            throw new MiExcepcion(106, e.getMessage());
        }
    }

    // ----------------------------------------------------------------
    // DELETE
    // ----------------------------------------------------------------

    /**
     * Elimina el guion con el id indicado.
     *
     * @return número de filas afectadas (1 si se eliminó correctamente)
     */
    public static int eliminarGuion(int id) throws MiExcepcion {
        Connection con = GestionConexion.getConexion();
        if (con == null) throw new MiExcepcion(102);
        try {
            PreparedStatement ps = con.prepareStatement("DELETE FROM guion WHERE id = ?");
            ps.setInt(1, id);
            return ps.executeUpdate();
        } catch (SQLException e) {
            GestionLog.registrar(e);
            throw new MiExcepcion(107, e.getMessage());
        }
    }

    // ----------------------------------------------------------------
    // Helper: convertir una fila del ResultSet en un objeto Guion
    // ----------------------------------------------------------------

    private static Guion mapear(ResultSet rs) throws SQLException {
        Date sqlDate = rs.getDate("fechaEntrega");
        return new Guion(
            rs.getInt("id"),
            rs.getString("titulo"),
            rs.getDouble("duracion"),
            rs.getInt("paginas"),
            sqlDate != null ? sqlDate.toLocalDate() : null,
            rs.getString("descripcion"),
            rs.getInt("pelId")
        );
    }
}
