package modelo;

import java.time.LocalDate;

/**
 * Representa un director de la base de datos (tabla director).
 * Es también el usuario que inicia sesión en la aplicación.
 *
 * Campos importantes:
 *   - foto     → nombre del fichero de imagen dentro de la carpeta fotos/
 *   - dirTutor → id de otro director que actúa como mentor (puede ser null)
 */
public class Director {

    private int       id;
    private String    nombre;
    private String    usuario;
    private String    contrasena;
    private String    nacionalidad;
    private LocalDate fechaNac;
    private String    foto;       // nombre del fichero, ej: "pepito.jpg"
    private Integer   dirTutor;   // FK autorrelación — null si no tiene mentor

    public Director(int id, String nombre, String usuario, String contrasena,
                    String nacionalidad, LocalDate fechaNac, String foto, Integer dirTutor) {
        this.id           = id;
        this.nombre       = nombre;
        this.usuario      = usuario;
        this.contrasena   = contrasena;
        this.nacionalidad = nacionalidad;
        this.fechaNac     = fechaNac;
        this.foto         = foto;
        this.dirTutor     = dirTutor;
    }

    // Getters y setters

    public int    getId()          { return id; }
    public void   setId(int v)     { this.id = v; }

    public String getNombre()          { return nombre; }
    public void   setNombre(String v)  { this.nombre = v; }

    public String getUsuario()           { return usuario; }
    public void   setUsuario(String v)   { this.usuario = v; }

    public String getContrasena()            { return contrasena; }
    public void   setContrasena(String v)    { this.contrasena = v; }

    public String getNacionalidad()              { return nacionalidad; }
    public void   setNacionalidad(String v)      { this.nacionalidad = v; }

    public LocalDate getFechaNac()             { return fechaNac; }
    public void      setFechaNac(LocalDate v)  { this.fechaNac = v; }

    public String getFoto()          { return foto; }
    public void   setFoto(String v)  { this.foto = v; }

    public Integer getDirTutor()           { return dirTutor; }
    public void    setDirTutor(Integer v)  { this.dirTutor = v; }

    @Override
    public String toString() {
        return nombre + " [" + usuario + "]";
    }
}
