package modelo;

/**
 * Representa una película de la base de datos (tabla pelicula).
 *
 * Campos importantes:
 *   - duracionTotal  → se calcula automáticamente sumando la duración de sus guiones
 *   - duracionMaxima → límite máximo permitido (no se puede superar al añadir guiones)
 *   - dirId          → id del director al que pertenece (clave foránea)
 */
public class Pelicula {

    private int    id;
    private String titulo;
    private String genero;
    private int    anio;
    private double presupuesto;    // euros
    private double duracionTotal;  // minutos — calculado sumando los guiones
    private double duracionMaxima; // minutos — tope máximo permitido
    private int    dirId;          // FK → director.id

    public Pelicula(int id, String titulo, String genero, int anio,
                    double presupuesto, double duracionTotal, double duracionMaxima, int dirId) {
        this.id            = id;
        this.titulo        = titulo;
        this.genero        = genero;
        this.anio          = anio;
        this.presupuesto   = presupuesto;
        this.duracionTotal  = duracionTotal;
        this.duracionMaxima = duracionMaxima;
        this.dirId         = dirId;
    }

    // Getters y setters

    public int    getId()          { return id; }
    public void   setId(int id)    { this.id = id; }

    public String getTitulo()              { return titulo; }
    public void   setTitulo(String v)      { this.titulo = v; }

    public String getGenero()              { return genero; }
    public void   setGenero(String v)      { this.genero = v; }

    public int  getAnio()          { return anio; }
    public void setAnio(int v)     { this.anio = v; }

    public double getPresupuesto()         { return presupuesto; }
    public void   setPresupuesto(double v) { this.presupuesto = v; }

    public double getDuracionTotal()         { return duracionTotal; }
    public void   setDuracionTotal(double v) { this.duracionTotal = v; }

    public double getDuracionMaxima()         { return duracionMaxima; }
    public void   setDuracionMaxima(double v) { this.duracionMaxima = v; }

    public int  getDirId()         { return dirId; }
    public void setDirId(int v)    { this.dirId = v; }

    @Override
    public String toString() {
        return titulo + " (" + anio + ")";
    }
}
