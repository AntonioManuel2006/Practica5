package modelo;

/**
 * Excepción propia de la aplicación.
 * Lleva un código numérico que se puede consultar en CodigosError
 * para obtener el mensaje que se mostrará al usuario.
 *
 * Uso típico:
 *   throw new MiExcepcion(102);               // solo código
 *   throw new MiExcepcion(103, e.getMessage()); // código + mensaje técnico para el log
 */
public class MiExcepcion extends Exception {

    private final int codigo;

    /** Constructor con solo código (el mensaje será genérico). */
    public MiExcepcion(int codigo) {
        super("Error codigo: " + codigo);
        this.codigo = codigo;
    }

    /** Constructor con código y mensaje técnico (útil para registrar en el log). */
    public MiExcepcion(int codigo, String mensajeTecnico) {
        super(mensajeTecnico);
        this.codigo = codigo;
    }

    /** Devuelve el código de error para buscar su mensaje en CodigosError. */
    public int getCodigo() {
        return codigo;
    }
}
