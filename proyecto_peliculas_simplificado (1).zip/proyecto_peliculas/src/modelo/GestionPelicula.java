package modelo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Operaciones de acceso a datos de la tabla pelicula.
 *
 * Métodos disponibles:
 *   - obtenerPeliculas(sql)    → lista de películas resultado de una consulta
 *   - obtenerPelicula(id)      → una película por su id
 *   - obtenerPorDirector(id)   → todas las películas de un director
 *   - recalcularDuracion(id)   → actualiza duracionTotal sumando los guiones
 */
public class GestionPelicula {

    // ----------------------------------------------------------------
    // Consultas SELECT
    // ----------------------------------------------------------------

    /**
     * Ejecuta la SQL recibida y devuelve la lista de películas resultante.
     * Se usa internamente y desde la vista para cargar el cursor.
     */
    public static List<Pelicula> obtenerPeliculas(String sql) throws MiExcepcion {
        Connection con = GestionConexion.getConexion();
        if (con == null) throw new MiExcepcion(102);

        List<Pelicula> lista = new ArrayList<>();
        try {
            ResultSet rs = con.createStatement().executeQuery(sql);
            while (rs.next()) lista.add(mapear(rs));
            return lista;
        } catch (SQLException e) {
            GestionLog.registrar(e);
            throw new MiExcepcion(103, e.getMessage());
        }
    }

    /** Devuelve una película por su id, o null si no existe. */
    public static Pelicula obtenerPelicula(int id) throws MiExcepcion {
        Connection con = GestionConexion.getConexion();
        if (con == null) throw new MiExcepcion(102);
        try {
            PreparedStatement ps = con.prepareStatement(
                "SELECT id,titulo,genero,anio,presupuesto,duracionTotal,duracionMaxima,dirId " +
                "FROM pelicula WHERE id = ?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            return rs.next() ? mapear(rs) : null;
        } catch (SQLException e) {
            GestionLog.registrar(e);
            throw new MiExcepcion(103, e.getMessage());
        }
    }

    /** Devuelve todas las películas de un director. */
    public static List<Pelicula> obtenerPorDirector(int dirId) throws MiExcepcion {
        return obtenerPeliculas(
            "SELECT id,titulo,genero,anio,presupuesto,duracionTotal,duracionMaxima,dirId " +
            "FROM pelicula WHERE dirId=" + dirId);
    }

    // ----------------------------------------------------------------
    // Actualización del campo calculado
    // ----------------------------------------------------------------

    /**
     * Recalcula duracionTotal de la película sumando la duración de todos sus guiones.
     * Se debe llamar después de cada alta o baja en la tabla guion.
     *
     * Usa COALESCE para que devuelva 0 si la película no tiene guiones.
     */
    public static int recalcularDuracion(int pelId) throws MiExcepcion {
        Connection con = GestionConexion.getConexion();
        if (con == null) throw new MiExcepcion(102);
        try {
            PreparedStatement ps = con.prepareStatement(
                "UPDATE pelicula " +
                "SET duracionTotal = (SELECT COALESCE(SUM(duracion), 0) FROM guion WHERE pelId = ?) " +
                "WHERE id = ?");
            ps.setInt(1, pelId);
            ps.setInt(2, pelId);
            return ps.executeUpdate();
        } catch (SQLException e) {
            GestionLog.registrar(e);
            throw new MiExcepcion(109, e.getMessage());
        }
    }

    // ----------------------------------------------------------------
    // Helper: convertir una fila del ResultSet en un objeto Pelicula
    // ----------------------------------------------------------------

    private static Pelicula mapear(ResultSet rs) throws SQLException {
        return new Pelicula(
            rs.getInt("id"),
            rs.getString("titulo"),
            rs.getString("genero"),
            rs.getInt("anio"),
            rs.getDouble("presupuesto"),
            rs.getDouble("duracionTotal"),
            rs.getDouble("duracionMaxima"),
            rs.getInt("dirId")
        );
    }
}
