package modelo;

import java.time.LocalDate;

/**
 * Representa un guion de la base de datos (tabla guion).
 * Cada guion pertenece a una película (pelId).
 *
 * Al insertar o borrar un guion, la duración total de su película
 * se recalcula automáticamente desde GestionPelicula.recalcularDuracion().
 */
public class Guion {

    private int       id;
    private String    titulo;
    private double    duracion;      // minutos
    private int       paginas;
    private LocalDate fechaEntrega;  // puede ser null (campo opcional)
    private String    descripcion;
    private int       pelId;         // FK → pelicula.id

    public Guion(int id, String titulo, double duracion, int paginas,
                 LocalDate fechaEntrega, String descripcion, int pelId) {
        this.id           = id;
        this.titulo       = titulo;
        this.duracion     = duracion;
        this.paginas      = paginas;
        this.fechaEntrega = fechaEntrega;
        this.descripcion  = descripcion;
        this.pelId        = pelId;
    }

    // Getters y setters

    public int    getId()       { return id; }
    public void   setId(int v)  { this.id = v; }

    public String getTitulo()          { return titulo; }
    public void   setTitulo(String v)  { this.titulo = v; }

    public double getDuracion()          { return duracion; }
    public void   setDuracion(double v)  { this.duracion = v; }

    public int  getPaginas()       { return paginas; }
    public void setPaginas(int v)  { this.paginas = v; }

    public LocalDate getFechaEntrega()             { return fechaEntrega; }
    public void      setFechaEntrega(LocalDate v)  { this.fechaEntrega = v; }

    public String getDescripcion()           { return descripcion; }
    public void   setDescripcion(String v)   { this.descripcion = v; }

    public int  getPelId()       { return pelId; }
    public void setPelId(int v)  { this.pelId = v; }

    @Override
    public String toString() {
        return titulo + " (" + duracion + " min)";
    }
}
