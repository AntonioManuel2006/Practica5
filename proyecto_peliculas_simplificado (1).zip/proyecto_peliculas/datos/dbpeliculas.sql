-- ============================================================
--  BASE DE DATOS: bdpeliculas
--  Esquema ER: director (A) --> pelicula (B) --> guion (C)
--  FK naming: 3 primeras letras de la tabla origen + nombre PK
--    · pelicula.dirId  --> director.id
--    · guion.pelId     --> pelicula.id
--    · director.dirTutor --> director.id  (autorrelación: director mentor)
-- ============================================================

CREATE DATABASE IF NOT EXISTS bdpeliculas
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE bdpeliculas;

-- -------------------------------------------------------
-- TABLA A – director  (tabla de validación / login)
-- -------------------------------------------------------
CREATE TABLE director (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    nombre        VARCHAR(100)  NOT NULL,
    usuario       VARCHAR(50)   NOT NULL UNIQUE,
    contrasena    VARCHAR(100)  NOT NULL,
    nacionalidad  VARCHAR(60),
    fechaNac      DATE,
    foto          VARCHAR(255),          -- nombre del fichero en carpeta fotos/
    dirTutor      INT,                   -- autorrelación: director mentor
    CONSTRAINT fk_dir_tutor FOREIGN KEY (dirTutor) REFERENCES director(id)
);

-- -------------------------------------------------------
-- TABLA B – pelicula  (campo calculado + campo tope)
-- -------------------------------------------------------
CREATE TABLE pelicula (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    titulo          VARCHAR(200)   NOT NULL,
    genero          VARCHAR(60),
    anio            INT,
    presupuesto     DECIMAL(14,2),        -- campo real
    duracionTotal   DECIMAL(7,2)  DEFAULT 0,  -- CAMPO CALCULADO (SUM de guion.duracion)
    duracionMaxima  DECIMAL(7,2)  NOT NULL,   -- CAMPO TOPE
    dirId           INT           NOT NULL,
    CONSTRAINT fk_pel_director FOREIGN KEY (dirId) REFERENCES director(id)
);

-- -------------------------------------------------------
-- TABLA C – guion
-- -------------------------------------------------------
CREATE TABLE guion (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    titulo        VARCHAR(200)  NOT NULL,
    duracion      DECIMAL(6,2)  NOT NULL,  -- minutos (campo real)
    paginas       INT,
    fechaEntrega  DATE,
    descripcion   VARCHAR(500),
    pelId         INT           NOT NULL,
    CONSTRAINT fk_gui_pelicula FOREIGN KEY (pelId) REFERENCES pelicula(id)
);

-- -------------------------------------------------------
-- DATOS DE PRUEBA
-- -------------------------------------------------------
INSERT INTO director (nombre, usuario, contrasena, nacionalidad, fechaNac, foto, dirTutor) VALUES
('Steven Spielberg',   'spielberg',  '1234', 'Americana',  '1946-12-18', NULL, NULL),
('Christopher Nolan',  'nolan',      '1234', 'Britanica',  '1970-07-30', NULL, 1),
('Quentin Tarantino',  'tarantino',  '1234', 'Americana',  '1963-03-27', NULL, 1);

INSERT INTO pelicula (titulo, genero, anio, presupuesto, duracionTotal, duracionMaxima, dirId) VALUES
('Inception',         'Ciencia Ficcion', 2010, 160000000.00, 0, 180, 2),
('Interstellar',      'Ciencia Ficcion', 2014, 165000000.00, 0, 200, 2),
('Pulp Fiction',      'Crimen',          1994,   8500000.00, 0, 160, 3),
('E.T.',              'Fantasia',        1982,  10500000.00, 0, 120, 1);

INSERT INTO guion (titulo, duracion, paginas, fechaEntrega, descripcion, pelId) VALUES
('Acto 1 - El Sueno',   45.5,  55, '2009-01-15', 'Introduccion al mundo de los suenos',    1),
('Acto 2 - La Mision',  60.0,  70, '2009-06-20', 'El equipo planea el robo de inception',  1),
('Viaje Espacial',      80.0,  95, '2013-03-10', 'Exploracion del agujero de gusano',      2),
('La Conversacion',     35.5,  42, '1993-08-05', 'Dialogos en la cafeteria',               3),
('Los Tiempos Muertos', 30.0,  38, '1993-11-01', 'Escenas de transicion',                  3);

-- Recalcular duracionTotal tras insertar guiones
UPDATE pelicula p
SET p.duracionTotal = (
    SELECT COALESCE(SUM(g.duracion), 0)
    FROM guion g
    WHERE g.pelId = p.id
);
